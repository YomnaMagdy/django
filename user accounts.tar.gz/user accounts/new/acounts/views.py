from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
# Create your views here.
def signup (request):
    if request.method=='POST':

        form=UserCreationForm(request.POST)#post to push all data user entered
        if form.is_valid():
            form.save()
            #login
            return redirect('newapp:app')
    else:
        form=UserCreationForm()
    return render(request,'acounts/signup.html',{'form':form})
#this function will be called when user click signup so we need
#to let is be 2 ways which give to the user request and take from him
#so we will make condition on the request (up)
