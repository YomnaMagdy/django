from django.contrib import admin
from .models import APP_MODEL
# Register your models here.
admin.site.register(APP_MODEL)
