from django.shortcuts import render
from .models import APP_MODEL
from django.http import HttpResponse
# Create your views here.
def app(request):
    model=APP_MODEL.objects.all()
    return render(request,'app/apptemp.html',{'model':model})
    #we want to make a local template so we will make a new file in the app leaving template file to be the global
    # we made the templates local one and then sub folder called app in order to avoid distracting of django to render which template folder
def ModelDetail(request,slug):
    #return HttpResponse(slug)
    var=APP_MODEL.objects.get(slug=slug) #we want to get the slug from database do themodel.objects.get will search for it
    return render(request,'app/detail.html',{'var':var})
