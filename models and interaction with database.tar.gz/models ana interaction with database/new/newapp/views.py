from django.shortcuts import render

# Create your views here.
def app(request):
    return render(request,'app/apptemp.html')
    #we want to make a local template so we will make a new file in the app leaving template file to be the global
    # we made the templates local one and then sub folder called app in order to avoid distracting of django to render which template folder
